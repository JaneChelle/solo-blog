title: 初始webpack
date: '2019-05-27 02:01:34'
updated: '2019-08-05 15:06:06'
tags: [初始webpack, 前端]
permalink: /articles/2019/05/27/1563541791913.html
---
#### 一、在网页中会引入那些静态资源？

 - js
>  - .js、.coffee、.ts等等

  
 - -css
> 	- .css、.sass，.less等等

 - images
> - .jpeg、.png、.gif、.bmp、.svg

 - 字体文件
>  - .svg、.ttf、.eot、.woff、.woff2等等

 - 模板文件
>  - .ejs、.jade、.vue[这是在webpack中定义组件的方式，推荐这么用]

#### 二、网页在静态资源引入多了以后有什么问题？

 1. 网页加载速度慢，因为我们有很多的二次请求
 2. 要处理错综复杂的依赖关系

#### 三、如何处理上述问题？

 1. 合并、压缩、精灵图、图片的base64码
 2. 使用requirejs、webpack处理上述问题
 
#### 四、什么是webpack？
 Webpack可以合并、压缩、处理图片的Base64编码，及解决各个包之间复杂的依赖关系。
 webpack就是个打包工具。
 #### 五、webpack可以做什么？
 
 1.  webpack能处理JS文件的互相依赖关系；
 2. webpack能够处理JS的兼容问题，把高级的，不能识别的语法，转为低级的，浏览器能正常识别的语法