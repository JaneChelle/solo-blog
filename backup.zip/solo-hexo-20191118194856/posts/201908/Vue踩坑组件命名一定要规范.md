title: Vue踩坑---组件命名一定要规范
date: '2019-08-17 11:39:29'
updated: '2019-08-17 11:46:30'
tags: [Vue, 前端]
permalink: /articles/2019/08/17/1566013169053.html
---
![](https://img.hacpai.com/bing/20190527.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

#### 一、组件命名
  在写Vue项目的时候，用cube-ui的createAPI创建一个组件，结果运行的时候，报错信息是这样的：

![image.png](https://img.hacpai.com/file/2019/08/image-3214873f.png)

  怎么可能，让我npm 安装？这不是npm的事。后来又排查了老半天，把shopcart的组件名给改成了shop-cart，不报错了，没想到shop-cart组件名会影响到shoop-cart-list。Vue给出了官方的命名规范：

![image.png](https://img.hacpai.com/file/2019/08/image-0e285902.png)


> 当注册组件 (或者 prop) 时，可以使用 kebab-case (短横线分隔命名)、camelCase (驼峰式命名) 或 PascalCase (单词首字母大写命名)。
PascalCase 是最通用的声明约定而 kebab-case 是最通用的使用约定。

命名可遵循以下规则：

>  1、有意义的名词、简短、具有可读性
 2、以小写开头，采用短横线分割命名
 3、基础组件名以Base、App 或 V开头
4、文件夹命名主要以功能模块代表命名
   这就是我的问题所在！:sweat_smile::sweat_smile:
  以后开发一定要注意命名规范，减少不必要的问题，且容易维护。
#### 二、Vue组件中的方法书写顺序

```
    - components   
    - props    
    - data     
    - created
    - mounted
    - activited
    - update
    - beforeRouteUpdate
    - metods   
    - filter
    - computed
    - watch
```
  还有很多细节问题，大家可以参考Vuejs的官方文档[风格指南](https://cn.vuejs.org/v2/style-guide/index.html)