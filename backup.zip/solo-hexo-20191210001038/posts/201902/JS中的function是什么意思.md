title: JS中的 $(function(){ } 是什么意思
date: '2019-02-21 04:32:06'
updated: '2019-08-05 15:07:14'
tags: [js, 前端]
permalink: /articles/2019/02/21/1563541788418.html
---
```javascript
<script type="text/javascript">
 $(function(){

 });
</script>

```

	$(function(){ })  是$(document).ready(function()的简写（JQuery写法：页面框架加载完成就执行）

	相当于window.onload = function(){ } （JS写法：页面中所有内容加载完成才执行）

	虽然这段jquery代码与javascript代码在功能上可以互换

	但注意：两者执行的时间不一样

	前者页面框架加载完成就执行

	后者页面中所有内容加载完成才执行