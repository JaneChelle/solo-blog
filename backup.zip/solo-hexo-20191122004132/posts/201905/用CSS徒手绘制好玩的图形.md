title: 用CSS徒手绘制好玩的图形
date: '2019-05-27 02:01:34'
updated: '2019-08-05 15:06:31'
tags: [用CSS绘制图形, 前端]
permalink: /articles/2019/05/27/1563541800654.html
---
![](https://img.hacpai.com/bing/20180413.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

@[TOC](用CSS徒手绘制好玩的图形)

## 以下这些造型简单的图形都是纯CSS外加一个HTML标签实现的。

原文链接：by zhangxinxu from https://www.zhangxinxu.com/wordpress/?p=8386

#####  1.弧形尾箭头

效果如下：

![4SS1OV05WB7YVEQSXCNZL.png](https://img.hacpai.com/file/2019/07/4SS1OV05WB7YVEQSXCNZL-04608bcc.png)


完整CSS代码：

```css
#curvedarrow {
  position: relative;
  width: 0;
  border-top: 90px solid transparent;
  border-right: 90px solid red;
  transform: rotate(10deg) translateX(100%);
}
#curvedarrow:after {
  content: "";
  position: absolute;
  border: 0 solid transparent;
  border-top: 30px solid red;
  border-radius: 200px 0 0 0;
  top: -120px; left: -90px;
  width: 120px; height: 120px;
  transform: rotate(45deg);
}
```



#####  2.六角星

效果如下：

![SSU40R2ZB8RTCZF7.png](https://img.hacpai.com/file/2019/07/SSU40R2ZB8RTCZF7-608fcc5f.png)


完整CSS代码：

```css
#star-six {
  width: 0;
  border-left: 50px solid transparent;
  border-right: 50px solid transparent;
  border-bottom: 100px solid red;
  position: relative;
}
#star-six:after {
  border-left: 50px solid transparent;
  border-right: 50px solid transparent;
  border-top: 100px solid red;
  position: absolute;
  content: "";
  top: 30px; left: -50px;
}
```


#####  3.五角星

效果如下：

![BT9V5CBFR483QGYHG.png](https://img.hacpai.com/file/2019/07/BT9V5CBFR483QGYHG-cd90e6e9.png)


五角星实现难度要比六角形大得多，CSS代码为：

```css
#star-five {
  margin: 50px 0;
  position: relative;
  color: red;
  width: 0px;
  border-right: 100px solid transparent;
  border-bottom: 70px solid red;
  border-left: 100px solid transparent;
  transform: rotate(35deg);
}
#star-five:before {
  border-bottom: 80px solid red;
  border-left: 30px solid transparent;
  border-right: 30px solid transparent;
  position: absolute;
  top: -45px; left: -65px;
  content: '';
  transform: rotate(-35deg);
}
#star-five:after {
  position: absolute;
  color: red;
  top: 3px; left: -105px;
  border-right: 100px solid transparent;
  border-bottom: 70px solid red;
  border-left: 100px solid transparent;
  transform: rotate(-70deg);
  content: '';
}
```



#####  4. 多边形-五边形

效果如下：

![3T9EB8YFC0MMRPVPLSN9.png](https://img.hacpai.com/file/2019/07/3T9EB8YFC0MMRPVPLSN9-8424e231.png)


完整CSS代码：

```css
#pentagon {
  position: relative;
  width: 54px;
  box-sizing: content-box;
  border-width: 50px 18px 0;
  border-style: solid;
  border-color: red transparent;
}
#pentagon:before {
  content: "";
  position: absolute;
  top: -85px; left: -18px;
  border-width: 0 45px 35px;
  border-style: solid;
  border-color: transparent transparent red;
}
```



#####  5. 多边形-六边形

效果如下：

![U94KNTTTB2ROUAP.png](https://img.hacpai.com/file/2019/07/U94KNTTTB2ROUAP-64c4dfdd.png)


完整CSS代码：

```css
#hexagon {
  width: 100px; height: 55px;
  background: red;
  position: relative;
}
#hexagon:before {
  content: "";
  position: absolute;
  top: -25px; left: 0;
  border-left: 50px solid transparent;
  border-right: 50px solid transparent;
  border-bottom: 25px solid red;
}
#hexagon:after {
  content: "";
  position: absolute;
  bottom: -25px; left: 0;
  border-left: 50px solid transparent;
  border-right: 50px solid transparent;
  border-top: 25px solid red;
}
```


#####  6.带尖角的说话泡泡

效果如下：

![DWJXEASS91GKEBWR16E.png](https://img.hacpai.com/file/2019/07/DWJXEASS91GKEBWR16E-1164f658.png)


完整CSS代码：

```css
#talkbubble {
  width: 120px; height: 80px;
  background: red;
  position: relative;
  border-radius: 10px;
}
#talkbubble:before {
  content: "";
  position: absolute;
  right: 100%; top: 26px;
  border-top: 13px solid transparent;
  border-right: 26px solid red;
  border-bottom: 13px solid transparent;
}
```


#####  7.爱心❥

效果如下：

![SUB7YKDC0K78FCAIFTK.png](https://img.hacpai.com/file/2019/07/SUB7YKDC0K78FCAIFTK-3eb94dc1.png)


完整CSS代码：

```css
#heart {
  position: relative;
  width: 100px; height: 90px;
}
#heart:before,
#heart:after {
  position: absolute;
  content: "";
  left: 50px; top: 0;
  width: 50px; height: 80px;
  background: red;
  border-radius: 50px 50px 0 0;
  transform: rotate(-45deg);
  transform-origin: 0 100%;
}
#heart:after {
  left: 0;
  transform: rotate(45deg);
  transform-origin: 100% 100%;
}
```


#####  8.无限

效果如下：

![JTBAZGBB2LS87VDSP6.png](https://img.hacpai.com/file/2019/07/JTBAZGBB2LS87VDSP6-259fe238.png)


完整CSS代码：

```css
#infinity {
  position: relative;
  width: 212px; height: 100px;
  box-sizing: content-box;
}
#infinity:before,
#infinity:after {
  content: "";
  box-sizing: content-box;
  position: absolute;
  top: 0; left: 0;
  width: 60px; height: 60px;
  border: 20px solid red;
  border-radius: 50px 50px 0 50px;
  transform: rotate(-45deg);
}
#infinity:after {
  left: auto; right: 0;
  border-radius: 50px 50px 50px 0;
  transform: rotate(45deg);
}
```


#####  9.切割菱形-钻石般

效果如下：

![36FS26ISVE9QY31MH.png](https://img.hacpai.com/file/2019/07/36FS26ISVE9QY31MH-b86b2c27.png)


值钱的CSS代码：

```css
#cut-diamond {
  border-style: solid;
  border-color: transparent transparent red transparent;
  border-width: 0 25px 25px 25px;
  width: 50px;
  box-sizing: content-box;
  position: relative;
  margin: 20px 0 50px 0;
}
#cut-diamond:after {
  content: "";
  position: absolute;
  top: 25px; left: -25px;
  border-style: solid;
  border-color: red transparent transparent transparent;
  border-width: 70px 50px 0 50px;
}
```



#####  10.鸡蛋形状

效果如下：

![LUO487MIOE8UR89UFLT.png](https://img.hacpai.com/file/2019/07/LUO487MIOE8UR89UFLT-e91c4325.png)


实现也很简单，就一个border-radius就可以了：

```css
#egg {
  display: block;
  width: 126px;
  height: 180px;
  background-color: red;
  border-radius: 50% 50% 50% 50% / 60% 60% 40% 40%;
}
```



#####  11. 吃豆人

效果如下：

![A37MIUXEUIIP5M3Y1.png](https://img.hacpai.com/file/2019/07/A37MIUXEUIIP5M3Y1-f9bbf764.png)


相关CSS代码：

```css
#pacman {
  width: 0px; height: 0px;
  border-right: 60px solid transparent;
  border-top: 60px solid red;
  border-left: 60px solid red;
  border-bottom: 60px solid red;
  border-top-left-radius: 60px;
  border-top-right-radius: 60px;
  border-bottom-left-radius: 60px;
  border-bottom-right-radius: 60px;
}
```

#####  12. 十二星

效果如下：

![GX2N0DIKUO2SB1LJJ.png](https://img.hacpai.com/file/2019/07/GX2N0DIKUO2SB1LJJ-735a0cdd.png)


相关CSS代码：

```css
#burst-12 {
  background: red;
  width: 80px;
  height: 80px;
  position: relative;
  text-align: center;
}
#burst-12:before,
#burst-12:after {
  content: "";
  position: absolute;
  top: 0;
  left: 0;
  height: 80px;
  width: 80px;
  background: red;
}
#burst-12:before {
  transform: rotate(30deg);
}
#burst-12:after {
  transform: rotate(60deg);
}
```

#####  13. 阴阳八卦

效果如下：

![XFE9KSJRRTCCX65Q.png](https://img.hacpai.com/file/2019/07/XFE9KSJRRTCCX65Q-bdde7ad1.png)


相关CSS代码：

```css
#yin-yang {
  width: 96px; height: 48px;
  background: #eee;
  border-color: red;
  border-style: solid;
  border-width: 2px 2px 50px 2px;
  border-radius: 100%;
  position: relative;
}
#yin-yang:before {
  content: "";
  position: absolute;
  top: 50%; left: 0;
  background: #fff;
  border: 18px solid red;
  border-radius: 100%;
  width: 12px; height: 12px;
}
#yin-yang:after {
  content: "";
  position: absolute;
  top: 50%;
  left: 50%;
  background: red;
  border: 18px solid #eee;
  border-radius: 100%;
  width: 12px;
  height: 12px;
}
```

#####  14. 徽章缎带

效果如下：

![SO11WOMWKNXD5W6.png](https://img.hacpai.com/file/2019/07/SO11WOMWKNXD5W6-5a5bbc3e.png)


相关CSS代码：

```css
#badge-ribbon {
  position: relative;
  background: red;
  height: 100px; width: 100px;
  border-radius: 50px;
}
#badge-ribbon::before,
#badge-ribbon::after {
  content: '';
  position: absolute;
  border-bottom: 70px solid red;
  border-left: 40px solid transparent;
  border-right: 40px solid transparent;
  top: 70px; left: -10px;
  transform: rotate(-140deg);
}
#badge-ribbon::after {
  left: auto;
  right: -10px;
  transform: rotate(140deg);
}
```

#####  15. 放大镜

效果如下：

![R73RWPL10GW5ZOBC9.png](https://img.hacpai.com/file/2019/07/R73RWPL10GW5ZOBC9-42b33aa2.png)

可以作为搜索按钮
相关CSS代码：

```css
#magnifying-glass {
  font-size: 10em;
  display: inline-block;
  width: 0.4em; height: 0.4em;
  border: 0.1em solid red;
  position: relative;
  border-radius: 0.35em;
}
#magnifying-glass:before {
  content: "";
  display: inline-block;
  position: absolute;
  right: -0.25em; bottom: -0.1em;
  border-width: 0;
  background: red;
  width: 0.35em; height: 0.08em;
  transform: rotate(45deg);
}
```

#####  16. 月儿弯弯

效果如下：

![M8HA8A83HYZQTRFBV.png](https://img.hacpai.com/file/2019/07/M8HA8A83HYZQTRFBV-6d5a0805.png)


相关CSS代码：

```css
#moon {
  width: 80px; height: 80px;
  border-radius: 50%;
  box-shadow: 15px 15px 0 0 red;
}
```

#####  17. 旗帜

效果如下：

![LRY0XDG9TFNQLEW2I.png](https://img.hacpai.com/file/2019/07/LRY0XDG9TFNQLEW2I-ac93b641.png)


相关CSS代码：

```css
#flag {
  width: 110px; height: 56px;
  padding-top: 15px;
  position: relative;
  background: red;
}
#flag:after {
  content: "";
  position: absolute;
  left: 0; bottom: 0;
  border-bottom: 13px solid #fff;
  border-left: 55px solid transparent;
  border-right: 55px solid transparent;
}
```

#####  18. 十字架

效果如下：

![YF7MJ988YZDQ7JV54A1.png](https://img.hacpai.com/file/2019/07/YF7MJ988YZDQ7JV54A1-b2cb6dbb.png)

可以作为添加按钮，或者添加图标
相关CSS代码：

```css
#cross {
  background: red;
  width: 20px; height: 100px;
  position: relative;
}
#cross:after {
  background: red;
  content: "";
  width: 100px; height: 20px;
  position: absolute;
  left: -40px; top: 40px;
}
```

#####  19. 长长的指向图形

效果如下：

![C9MWN4094T4EY07G1Y.png](https://img.hacpai.com/file/2019/07/C9MWN4094T4EY07G1Y-2e03a988.png)


相关CSS代码：

```css
#pointer {
  width: 200px; height: 40px;
  position: relative;
  background: red;
}
#pointer:after {
  content: "";
  position: absolute;
  left: 0; bottom: 0;
  border-left: 20px solid white;
  border-top: 20px solid transparent;
  border-bottom: 20px solid transparent;
}
#pointer:before {
  content: "";
  position: absolute;
  right: -20px; bottom: 0;
  border-left: 20px solid red;
  border-top: 20px solid transparent;
  border-bottom: 20px solid transparent;
}
```

#####  20. 锁

效果如下：

![KKNEYFZYHDKAX3P.png](https://img.hacpai.com/file/2019/07/KKNEYFZYHDKAX3P-15c16927.png)


相关CSS代码：

```css
#lock {
  font-size: 8px;
  position: relative;
  width: 18em; height: 13em;
  border-radius: 2em;
  top: 10em;
  box-sizing: border-box;
  border: 3.5em solid red;
  border-right-width: 7.5em;
  border-left-width: 7.5em;
  margin: 0 0 6rem 0;
}
#lock:before {
  content: "";
  box-sizing: border-box;
  position: absolute;
  border: 2.5em solid red;
  width: 14em; height: 12em;
  left: 50%;
  margin-left: -7em; top: -12em;
  border-top-left-radius: 7em;
  border-top-right-radius: 7em;
}
#lock:after {
  content: "";
  box-sizing: border-box;
  position: absolute;
  border: 1em solid red;
  width: 5em; height: 8em;
  border-radius: 2.5em;
  left: 50%; top: -1em;
  margin-left: -2.5em;
}
```

此效果实现作者是Colin Bate。
感谢你能够坚持阅读到这里！
👏👏