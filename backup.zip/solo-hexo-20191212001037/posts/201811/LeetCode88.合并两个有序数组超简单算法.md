title: LeetCode88. 合并两个有序数组（超简单算法）
date: '2018-11-23 23:51:41'
updated: '2019-08-05 15:08:05'
tags: [算法]
permalink: /articles/2018/11/23/1563543013564.html
---
### 自己总结的这个超级好理解的一种简单算法，供大家参考
方法如下：
```
class Solution {
    public static void merge(int[] nums1, int m, int[] nums2, int n) {
        for (int i = 0; i < nums2.length; i++) {
			nums1[nums1.length-1-i] = nums2[i];
		}
        Arrays.sort(nums1);
    }
}
```
完整输出如下(大家可以在控制台跑一下)：

```
import java.util.Arrays;
public class mykfirst {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//定义输出
		int[] arr1 = {1,2,4,6,0,0,0};
		int[] arr2 = {1,2,3};
        merge(arr1, 4, arr2, 3);
	}
	public static void merge(int[] nums1, int m, int[] nums2, int n) {
        for (int i = 0; i < nums2.length; i++) {
			nums1[nums1.length-1-i] = nums2[i];
		}
        Arrays.sort(nums1);
    }

}
```